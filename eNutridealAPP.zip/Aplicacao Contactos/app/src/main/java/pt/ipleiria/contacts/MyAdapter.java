package pt.ipleiria.contacts;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import pt.ipleiria.contacts.model.Contact;

public class MyAdapter extends ArrayAdapter {
    private final Context context;
    private ArrayList<Contact> contacts;

    public MyAdapter(Context context, ArrayList<Contact> contacts) {
        super(context, R.layout.item_contact, contacts);
        this.context = context;
        this.contacts = contacts;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_contact, parent, false);
        }
        Contact contact = contacts.get(position);
        TextView name = convertView.findViewById(R.id.textView_name);
        name.setText(contact.getName());
        TextView phone = convertView.findViewById(R.id.textView_phone);
        phone.setText("" + contact.getPhone());
        return convertView;
    }
}
