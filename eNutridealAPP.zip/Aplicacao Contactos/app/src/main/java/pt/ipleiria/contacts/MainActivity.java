package pt.ipleiria.contacts;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;

import org.json.JSONArray;

import java.util.HashMap;
import java.util.Map;

import pt.ipleiria.contacts.model.Agenda;
import pt.ipleiria.contacts.model.Contact;

public class MainActivity extends AppCompatActivity {

    private Agenda agenda;
    private ArrayAdapter<Contact> adapter;
    private ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.agenda = new Agenda();
        // dummy data
        Contact c1 = new Contact("Francisco Stromp", 961223344);
        Contact c2 = new Contact("Fernando Peyroteo", 932323232);
        Contact c3 = new Contact("Vítor Damas", 915566677);
        Contact c4 = new Contact("Rui Jordão", 967659876);
        Contact c5 = new Contact("Joseph Szabo", 234678905);
        this.agenda.addContact(c1);
        this.agenda.addContact(c2);
        this.agenda.addContact(c3);
        this.agenda.addContact(c4);
        this.agenda.addContact(c5);


        /*adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, agenda.getContacts());
        listView = findViewById(R.id.listView_contacts);
        listView.setAdapter(adapter);*/

        listView = findViewById(R.id.listView_contacts);
        adapter = new MyAdapter(this, agenda.getContacts());
        listView.setAdapter(adapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    public void onClick_AddItem(MenuItem item) {
        Toast.makeText(this, "Adicionar Contacto", Toast.LENGTH_SHORT).show();
    }

    public void onClick_SearchItem(MenuItem item) {
        Toast.makeText(this, "Procurar Contacto", Toast.LENGTH_SHORT).show();
    }


    public void onClick_NetworkItem(MenuItem item) {
        RequestQueue queue = Volley.newRequestQueue(this);

        //URL DA OPERAÇÃO
        final String url = "http://contactswebservice.apphb.com/Service.svc/rest/contacts";

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {

                //LOG PARA DEBUGGING
                Log.d("Response", response.toString());


                Gson gson = new Gson();

                //DESERILIZAR OS OBJETOS
                Contact[] contacts = gson.fromJson(response.toString(), Contact[].class);

                //ADICIONAR CONTACTOS
                for (Contact contact : contacts) {
                    agenda.addContact(contact);
                }
                adapter.notifyDataSetChanged();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Response", error.getMessage());
                Toast.makeText(MainActivity.this, "Error retrieving contacts from webservice.", Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            public Map<String, String> getHeaders() {
                HashMap<String, String> headers = new HashMap<>();
                headers.put("Content-Type", "application/json");
                return headers;
            }
        }; queue.add(request);
    }
}
