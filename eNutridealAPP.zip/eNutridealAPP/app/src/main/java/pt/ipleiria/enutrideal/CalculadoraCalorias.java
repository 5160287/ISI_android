package pt.ipleiria.enutrideal;

public class CalculadoraCalorias {
}
